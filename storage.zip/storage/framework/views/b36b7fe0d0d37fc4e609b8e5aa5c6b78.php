<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(ENV('APP_NAME')); ?></title>
	<?php echo app('Illuminate\Foundation\Vite')(['resources/css/bootstrap53.min.css']); ?>
  </head>
  <body style="background: #ff0d0d38">
    <nav class="navbar navbar-expand-lg bg-body-tertiary" style="background: blue;padding: 0">
        <div class="container-fluid" style="background: blue">
          <a class="navbar-brand text-white" href="<?php echo e(route('home')); ?>" target="_blank"><?php echo e(ENV('APP_NAME')); ?></a>
        <div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarScroll">
                <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
                  <li class="nav-item">
                    <a class="nav-link active text-white fw-bold" aria-current="page" href="<?php echo e(route('admin.order.index')); ?>">Order List</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link text-white fw-bold" href="#">Duplicate Orders</a>
                  </li>
                  
                  
                </ul>

              </div>
        </div>
        </div>
      </nav>
    <?php echo $__env->yieldContent('page_content'); ?>
	<?php echo app('Illuminate\Foundation\Vite')(['resources/js/bootstrap53.min.js']); ?>
    <?php echo $__env->yieldPushContent('js'); ?>
  </body>
</html>
<?php /**PATH D:\client-project\Sindeedbabay\resources\views/backend/layout/app.blade.php ENDPATH**/ ?>