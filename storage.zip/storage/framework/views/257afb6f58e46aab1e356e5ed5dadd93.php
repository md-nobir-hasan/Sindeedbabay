<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>INEEDBABY</title>
<style>
   /* .elementor-widget-container img{
        width: 40%;
    height: 40%;
    margin-top: 20px;
    }

    h1.elementor-heading-title{
        text-align: center;
    margin: 15px;
    font-size: 32px;
    } */

   p.elementor-heading-title {
        text-align: center;
    font-weight: bold;
    }
    /* .elementor-232 .elementor-element.elementor-element-d490292:not(.elementor-motion-effects-element-type-background), .elementor-232 .elementor-element.elementor-element-d490292 > .elementor-motion-effects-container > .elementor-motion-effects-layer {
    background-color: transparent;
    background-image: linear-gradient(180deg, #F8F6F8 80%, #FFFFFF 80%);

} */

</style>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/thank.css']); ?>
</head>

<body>
    <div class="cartflows-container">

        <div data-elementor-type="wp-post" data-elementor-id="232" class="elementor elementor-232">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-4f76747 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="4f76747" data-element_type="section"
                data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-79a6fd2"
                        data-id="79a6fd2" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-9833635 elementor-widget elementor-widget-image"
                                data-id="9833635" data-element_type="widget" data-widget_type="image.default">
                                <div class="elementor-widget-container">
                                    <style>
                                        /*! elementor - v3.6.6 - 08-06-2022 */
                                        .elementor-widget-image {
                                            text-align: center
                                        }

                                        .elementor-widget-image a {
                                            display: inline-block
                                        }

                                        .elementor-widget-image a img[src$=".svg"] {
                                            width: 48px
                                        }

                                        .elementor-widget-image img {
                                            vertical-align: middle;
                                            display: inline-block
                                        }
                                    </style> <a href="https://ineedbaby.com/">
                                        <img decoding="async" width="263" height="263"
                                            src="https://ineedbaby.com/wp-content/uploads/2023/06/347796153_3451667901747661_2294285393922809301_n.jpg"
                                            class="attachment-full size-full" alt="" loading="lazy"
                                            srcset="https://ineedbaby.com/wp-content/uploads/2023/06/347796153_3451667901747661_2294285393922809301_n.jpg 263w, https://ineedbaby.com/wp-content/uploads/2023/06/347796153_3451667901747661_2294285393922809301_n-150x150.jpg 150w, https://ineedbaby.com/wp-content/uploads/2023/06/347796153_3451667901747661_2294285393922809301_n-100x100.jpg 100w"
                                            sizes="(max-width: 263px) 100vw, 263px" /> </a>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-1f5e0bf elementor-widget elementor-widget-heading"
                                data-id="1f5e0bf" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <style>
                                        /*! elementor - v3.6.6 - 08-06-2022 */
                                        .elementor-heading-title {
                                            padding: 0;
                                            margin: 0;
                                            line-height: 1
                                        }

                                        .elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a {
                                            color: inherit;
                                            font-size: inherit;
                                            line-height: inherit
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-small {
                                            font-size: 15px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-medium {
                                            font-size: 19px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-large {
                                            font-size: 29px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xl {
                                            font-size: 39px
                                        }

                                        .elementor-widget-heading .elementor-heading-title.elementor-size-xxl {
                                            font-size: 59px
                                        }
                                    </style>
                                    <h1 class="elementor-heading-title elementor-size-default">Thank you</h1>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-9e7f7a3 elementor-widget elementor-widget-heading"
                                data-id="9e7f7a3" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <p class="elementor-heading-title elementor-size-default">আমাদের পণ্যটি কেনার জন্য
                                        আপনাকে অনেক ধন্যবাদ।</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-d490292 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="d490292" data-element_type="section"
                data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
                <div class="elementor-container elementor-column-gap-no">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-29ce87b"
                        data-id="29ce87b" data-element_type="column"
                        data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-33cd50b elementor-widget elementor-widget-order-details-form"
                                data-id="33cd50b" data-element_type="widget"
                                data-widget_type="order-details-form.default">
                                <div class="elementor-widget-container">
                                    <div
                                        class="cartflows-elementor__order-details-form cartflows-elementor__display-order-overview-yes cartflows-elementor__display-order-details-yes cartflows-elementor__display-billing-address-yes cartflows-elementor__display-shipping-address-yes">
                                        <div class='wcf-thankyou-wrap' id='wcf-thankyou-wrap'>
                                            <div class="woocommerce-order">



                                                <p
                                                    class="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received">
                                                    Your order has been received.</p>
                                                <ul
                                                    class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">

                                                    <li class="woocommerce-order-overview__order order">
                                                        Order number: <strong><?php echo e($order->id); ?></strong>
                                                    </li>

                                                    <li class="woocommerce-order-overview__date date">
                                                        Date: <strong><?php echo e($order->created_at); ?></strong>
                                                    </li>


                                                    <li class="woocommerce-order-overview__total total">
                                                        Total: <strong><span
                                                                class="woocommerce-Price-amount amount"><bdi><span
                                                                        class="woocommerce-Price-currencySymbol">&#2547;&nbsp;</span><?php echo e($order->qty*$order->p_price + $order->shipping_price); ?></bdi></span></strong>
                                                    </li>

                                                    <li class="woocommerce-order-overview__payment-method method">
                                                        Payment method: <strong>Cash on delivery</strong>
                                                    </li>

                                                </ul>


                                                <p>Pay with cash upon delivery.</p>
                                                <section class="woocommerce-order-details">

                                                    <h2 class="woocommerce-order-details__title">Order details</h2>

                                                    <table
                                                        class="woocommerce-table woocommerce-table--order-details shop_table order_details">

                                                        <thead>
                                                            <tr>
                                                                <th
                                                                    class="woocommerce-table__product-name product-name">
                                                                    Product</th>
                                                                <th
                                                                    class="woocommerce-table__product-table product-total">
                                                                    Total</th>
                                                            </tr>
                                                        </thead>

                                                        <tbody>
                                                            <tr class="woocommerce-table__line-item order_item">

                                                                <td
                                                                    class="woocommerce-table__product-name product-name">
                                                                    মরিয়ম ফুল <strong
                                                                        class="product-quantity">&times;&nbsp;<?php echo e($order->qty); ?></strong>
                                                                </td>

                                                                <td
                                                                    class="woocommerce-table__product-total product-total">
                                                                    <span class="woocommerce-Price-amount amount"><bdi><span
                                                                                class="woocommerce-Price-currencySymbol">&#2547;&nbsp;</span><?php echo e($order->qty*$order->p_price); ?></bdi></span>
                                                                </td>

                                                            </tr>

                                                        </tbody>

                                                        <tfoot>
                                                            <tr>
                                                                <th scope="row">Subtotal:</th>
                                                                <td><span class="woocommerce-Price-amount amount"><span
                                                                            class="woocommerce-Price-currencySymbol">&#2547;&nbsp;</span><?php echo e($order->qty*$order->p_price); ?></span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Shipping:</th>
                                                                <td><span class="woocommerce-Price-amount amount"><span
                                                                            class="woocommerce-Price-currencySymbol">&#2547;&nbsp;</span><?php echo e($order->shipping_price); ?></span>&nbsp;<small
                                                                        class="shipped_via">via Flat rate</small></td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Payment method:</th>
                                                                <td>Cash on delivery</td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">Total:</th>
                                                                <td><span class="woocommerce-Price-amount amount"><span
                                                                            class="woocommerce-Price-currencySymbol">&#2547;&nbsp;</span><?php echo e($order->qty*$order->p_price + $order->shipping_price); ?></span>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>

                                                </section>



                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-91f28dd elementor-align-center elementor-widget elementor-widget-button"
                                data-id="91f28dd" data-element_type="widget" data-widget_type="button.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-button-wrapper">
                                        <a href="<?php echo e(route('home')); ?>"
                                            class="elementor-button-link elementor-button elementor-size-sm"
                                            role="button">
                                            <span class="elementor-button-content-wrapper">
                                                <span class="elementor-button-text">আবারো অর্ডার করতে ক্লিক করুন</span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\client-project\Sindeedbabay\resources\views/thanks.blade.php ENDPATH**/ ?>