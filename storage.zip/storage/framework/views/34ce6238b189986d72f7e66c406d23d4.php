<?php $__env->startSection('page_content'); ?>
<div class="card text-center mt-4">
    <div class="card-header">
      Orders
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Note</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Shipping Price</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->address); ?></td>
                        <td><?php echo e($order->note); ?></td>
                        <td><?php echo e($order->qty); ?></td>
                        <td><?php echo e($order->p_price); ?></td>
                        <td><?php echo e($order->shipping_price); ?></td>
                        <td class="status" id="<?php echo e($order->id); ?>" style="cursor: pointer"><?php echo e($order->ShippingStatus->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($orders->links()): ?>
    <div class="card-footer text-body-secondary">
        <?php echo e($orders->links()); ?>

      </div>
    <?php endif; ?>

    <!-- Vertically centered scrollable modal -->
    <div class="modal fade" id="modal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content" id="modal-content">

          </div>
        </div>
      </div>

  </div>
 <script src="<?php echo e(asset('libraries/jquery37.min.js')); ?>"></script>
  <script>
    var order_id = null;
     $('.status').on('click',function(){
        order_id = $(this).attr('id');
            let modal_content = ` <div class="modal-header">
                                <h1 class="modal-title fs-5" id="modalLabel">Order Status</h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example">
                                        <option selected hidden>Choose Order Status </option>
                                        <?php $__currentLoopData = $order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($os->id); ?>"><?php echo e($os->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-primary order-status-update">Save changes</button>
                                </div>`;
        $('#modal-content').html(modal_content);
        $('#modal').modal('show');
        $('.order-status-update').on('click',function(){
            let order_status_id = $('.form-select').val();
            $.ajax({
                type: "get",
                url: `<?php echo e(route('admin.order-status.update')); ?>`,
                data: {id:order_id,os_id:order_status_id},
                dataType: "json",
                success: function (response) {
                    console.log(response)
                    if(response==1){
                        alert('Successfully status updated')
                        location.reload();
                    }else{
                        alert('Something wrong');
                    }
                }
            });

        });

     })
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\client-project\Sindeedbabay\resources\views/backend/order/index.blade.php ENDPATH**/ ?>